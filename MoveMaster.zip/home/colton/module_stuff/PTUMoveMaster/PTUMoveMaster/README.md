# PTUMoveMaster
This is an automation assistant for PTU. 

To invoke new menus, create a new script, enter the following, set the type to Script, select the token to use, and run the script. 

```
PTUAutoFight.ChatWindow(actor);
```
Manifest link:
https://raw.githubusercontent.com/caffyn/PTUMoveMaster/main/module.json 
